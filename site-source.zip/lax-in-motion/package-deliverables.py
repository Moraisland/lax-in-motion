from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json, hashlib
root = Path(__file__).parent
output = root.parent / 'deliverables'
output.mkdir(exist_ok=True)
base = ['docs','content','tests','README.md','START-HERE.md','package.json','assemble-content.py','make-illustrations.py']
files=[]
for item in base:
    p=root/item
    files.extend(sorted(p.rglob('*')) if p.is_dir() else [p])
files=[p for p in files if p.is_file()]
manifest={str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
for name, handoff in [('lax-in-motion-vscode.zip',False),('lax-in-motion-codex-handoff.zip',True)]:
    with ZipFile(output/name,'w',ZIP_DEFLATED) as archive:
        for p in files: archive.write(p,Path('lax-in-motion')/p.relative_to(root))
        if handoff:
            for item in ['HANDOFF.md','package-deliverables.py']: archive.write(root/item,'lax-in-motion/'+item)
            archive.writestr('lax-in-motion/FILE-MANIFEST.json',json.dumps(manifest,indent=2))
    with ZipFile(output/name) as archive:
        assert archive.testzip() is None
        assert 'lax-in-motion/docs/.nojekyll' in archive.namelist()
        assert 'lax-in-motion/docs/vendor/racing-bars.js' in archive.namelist()
    print(output/name)
