import { race, loadData } from './vendor/racing-bars.js';
import { normalize, dateLabel } from './data-model.js';
import { taskFrames, taskSummary, terminalColors } from './task-model.js';

const format = new Intl.NumberFormat('en-US');
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
let rowsPromise;
const demos = [...document.querySelectorAll('.task-result')].map(root => {
  const get = role => root.querySelector(`[data-demo="${role}"]`);
  const plot = get('plot');
  let racer, data = [], dates = [], busy = false, initialized = false;
  let countFrame = 0, displayed = 0, lastTotal = null;
  function decorate() {
    if (!racer) return;
    const { leaders, missing } = taskSummary(data, racer.getDate());
    plot.querySelectorAll('rect.bar').forEach(bar => {
      bar.classList.toggle('task-top-bar', root.dataset.task === 'leader' && leaders.includes(bar.__data__?.name));
    });
    plot.querySelectorAll('text.label').forEach(label => {
      const name = label.__data__?.name;
      if (name) { const text = name + (missing.includes(name) ? ' *' : ''); if (label.textContent !== text) label.textContent = text; }
    });
  }
  new MutationObserver(decorate).observe(plot, {childList:true, subtree:true});
  function countTo(total, animate) {
    cancelAnimationFrame(countFrame);
    const from = displayed;
    const start = performance.now();
    function draw(now) {
      const t = animate && !reducedMotion.matches ? Math.min(1, (now - start) / 600) : 1;
      displayed = from + (total - from) * (1 - (1 - t) ** 3);
      get('total').textContent = format.format(Math.round(displayed));
      if (t < 1) countFrame = requestAnimationFrame(draw);
    }
    countFrame = requestAnimationFrame(draw);
  }
  function sync() {
    if (!racer) return;
    const date = racer.getDate();
    const summary = taskSummary(data, date);
    get('date').textContent = dateLabel(date);
    get('timeline').value = dates.indexOf(date);
    get('play').textContent = racer.isRunning() ? 'Ⅱ Pause' : date === dates.at(-1) ? '↺ Replay' : '▶ Play';
    if (root.dataset.task === 'counter' && summary.total !== lastTotal) {
      countTo(summary.total, lastTotal !== null && racer.isRunning());
      lastTotal = summary.total;
    }
    if (root.dataset.task === 'leader') get('leader').textContent = summary.leaders.join(' & ') || 'No reported leader';
    plot.setAttribute('aria-label', `${dateLabel(date)}. Total: ${format.format(summary.total)} passenger movements. Leading terminal: ${summary.leaders.join(' and ')}.`);
    get('context').textContent = `${get('market').selectedOptions[0].textContent} · ${get('movement').selectedOptions[0].textContent}`;
    decorate();
  }
  async function build() {
    if (busy) return;
    busy = true;
    const previousDate = racer?.getDate();
    root.querySelectorAll('select, button, input').forEach(el => el.disabled = true);
    get('status').textContent = 'Loading the completed example…';
    try {
      rowsPromise ??= loadData('data/lax.csv', 'csv').then(normalize);
      const rows = await rowsPromise;
      racer?.destroy(); racer = null;
      data = taskFrames(rows, get('movement').value, get('market').value);
      lastTotal = null;
      racer = await race(data, `#${plot.id}`, {
        dataShape:'long', autorun:false, topN:12, colorMap:terminalColors,
        tickDuration: 1600 / Number(get('speed').value),
        labelsPosition:'outside', labelsWidth:174,
        marginLeft:12, marginRight:85, marginTop:30, marginBottom:20,
        minWidth:580, minHeight:440, dateCounter:'',
        valueDecimals:0, valueLocale:'en-US', makeCumulative:false, fixedScale:false,
        controlButtons:'none', overlays:'none', mouseControls:false, keyboardControls:false,
      });
      dates = racer.getAllDates();
      get('timeline').max = dates.length - 1;
      ['dateChange','play','pause','lastDate'].forEach(event => racer.on(event, sync));
      if (previousDate && dates.includes(previousDate)) racer.setDate(previousDate);
      sync(); initialized = true;
      get('status').textContent = 'Ready · Real LAX data · January–December 2019';
    } catch (error) {
      console.error(error);
      rowsPromise = null;
      get('status').textContent = 'Unable to load this example. Use Reset to retry.';
    } finally {
      busy = false;
      root.querySelectorAll('select, button, input').forEach(el => el.disabled = false);
      get('play').disabled = !racer;
      get('timeline').disabled = !racer;
    }
  }
  get('play').addEventListener('click', () => {
    if (!racer || busy) return;
    if (racer.getDate() === dates.at(-1)) racer.skipBack();
    racer.toggle();
  });
  get('reset').addEventListener('click', () => {
    if (!racer) { build(); return; }
    racer.pause(); racer.skipBack(); sync();
  });
  get('timeline').addEventListener('input', () => {
    racer.pause(); racer.setDate(dates[Number(get('timeline').value)]); sync();
  });
  for (const role of ['market','movement','speed']) get(role).addEventListener('change', build);
  return { open:() => { if (!initialized && !busy) build(); }, pause:() => racer?.pause() };
});
function routeDemos() {
  demos.forEach(demo => location.hash === '#task' ? demo.open() : demo.pause());
}
addEventListener('hashchange', routeDemos);
document.addEventListener('visibilitychange', () => { if (document.hidden) demos.forEach(demo => demo.pause()); });
routeDemos();
