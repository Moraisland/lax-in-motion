import { excerptSpecs, extractExcerpt } from './excerpts.js';
import { race, loadData } from './vendor/racing-bars.js';
import { normalize, filterRows, aggregate, completeFrames, dateLabel } from './data-model.js';
import { initRecovery, pauseRecovery } from './recovery.js';
const $ = id => document.getElementById(id);
const fmt = new Intl.NumberFormat('en-US');
const names = ['T1','T2','T3','T4','T5','T6','T7','T8','TBIT','TBIT West Gates','Imperial Terminal','Miscellaneous Terminal'];
const colorMap = Object.fromEntries(names.map((name, i) => [name, ['#1746aa','#2b78b7','#4c65c6','#5d9ac9','#233b77','#728bc4','#157c96','#548ca6','#2563eb','#769fda','#667b95','#99abc3'][i]]));
let racer, rows, chartData, dates = [], active, busy = false;
function settings() { return { start: $('start').value, end: $('end').value, movement: $('movement').value, market: $('market').value }; }
function error(message = '') { $('error').textContent = message; $('error').hidden = !message; }
function annotateMissing() {
  if (!racer) return;
  const missing = new Set(chartData.filter(d => d.date === racer.getDate() && d.missing).map(d => d.name));
  $('race').querySelectorAll('text.label').forEach(label => {
    const name = label.textContent.replace(/ \*$/, '');
    const text = name + (missing.has(name) ? ' *' : '');
    if (label.textContent !== text) label.textContent = text;
  });
}
// The library creates its SVG asynchronously, after race() can already resolve.
new MutationObserver(records => {
  if (records.some(record => [...record.addedNodes].some(node => node.nodeType === 1))) annotateMissing();
}).observe($('race'), { childList: true, subtree: true });
function sync() {
  if (!racer) return;
  const date = racer.getDate();
  const index = dates.indexOf(date);
  $('current').textContent = dateLabel(date);
  $('scrub').value = Math.max(0, index);
  $('play').textContent = racer.isRunning() ? 'Ⅱ Pause race' : index === dates.length - 1 && dates.length > 1 ? '↺ Replay race' : '▶ Play race';
  $('frameCount').textContent = `${index + 1} / ${dates.length} months`;
  const slice = chartData.filter(d => d.date === date).sort((a, b) => b.value - a.value || a.name.localeCompare(b.name));
  // Names stay stable for RacingBars; the asterisk only changes the visible label.
  annotateMissing();
  const total = slice.reduce((sum, d) => sum + d.value, 0);
  const leaders = slice.filter(d => d.value === slice[0]?.value);
  $('insight').textContent = total > 0 ? `${leaders.map(d => d.name).join(' & ')} ${leaders.length > 1 ? 'lead' : 'leads'} with ${fmt.format(slice[0].value)} movements · ${fmt.format(total)} reported in total.` : 'No positive passenger movements reported for this selection.';
  $('race').setAttribute('aria-label', `${dateLabel(date)}: ${$('insight').textContent} Detailed values are available in the data table below.`);
  $('tableCaption').textContent = `${dateLabel(date)} · ${$('context').textContent}`;
  $('dataTable').replaceChildren(...slice.map(item => {
    const { name } = item;
    const tr = document.createElement('tr');
    const a = document.createElement('td'); a.textContent = name;
    const b = document.createElement('td');
    b.textContent = item.missing ? 'Not reported' : fmt.format(item.value);
    tr.append(a, b); return tr;
  }));
}
async function build() {
  if (busy) return;
  const selection = settings();
  if (selection.start > selection.end) { error('Start month must be on or before end month. Your current chart has been kept.'); return; }
  const nextData = aggregate(filterRows(rows, selection));
  if (!nextData.length) { error('No source records match this selection. Choose another range or filter.'); return; }
  busy = true; error();
  const controls = [...document.querySelectorAll('#filters select, #filters button, .player button, .player input')];
  controls.forEach(el => el.disabled = true);
  $('apply').textContent = 'Updating…';
  try {
    if (racer) { racer.destroy(); racer = null; }
    chartData = completeFrames(nextData, names); active = selection;
    // lesson:race:start
    racer = await race(chartData, '#race', {
      dataShape: 'long',
      autorun: false,
      topN: 12,
      tickDuration: 1200 / Number($('speed').value),
      colorMap,
      labelsPosition: 'outside', labelsWidth: 180,
      marginLeft: 16, marginRight: 80,
      marginTop: 35, marginBottom: 68,
      minWidth: 580, minHeight: 400,
      dateCounter: 'MMM YYYY',
      valueDecimals: 0, valueLocale: 'en-US',
      makeCumulative: false, fixedScale: false,
      controlButtons: 'none', overlays: 'none',
      mouseControls: false, keyboardControls: false,
      highlightBars: true
    });
    // lesson:race:end
    dates = racer.getAllDates();
    $('scrub').max = dates.length - 1;
    $('rangeStart').textContent = dateLabel(dates[0]);
    $('rangeEnd').textContent = dateLabel(dates.at(-1));
    $('context').textContent = `Monthly passenger movements · ${active.movement === 'All' ? 'Arrivals + departures' : active.movement === 'Arrival' ? 'Arrivals' : 'Departures'} · ${active.market === 'All' ? 'Domestic + international' : active.market}`;
    ['dateChange','play','pause','lastDate'].forEach(event => racer.on(event, sync));
    $('pending').hidden = true;
    sync();
  } catch (e) { console.error(e); error('The chart could not load. Please reload the page or download the source CSV below.'); }
  finally {
    busy = false; controls.forEach(el => el.disabled = false);
    $('play').disabled = !racer || dates.length < 2;
    $('reset').disabled = !racer;
    $('scrub').disabled = !racer || dates.length < 2;
    $('apply').textContent = 'Apply filters ↗';
  }
}
$('filters').addEventListener('submit', event => { event.preventDefault(); build(); });
['start','end','movement','market'].forEach(id => $(id).addEventListener('change', () => {
  $('pending').hidden = false; racer?.pause(); sync();
}));
// lesson:controls:start
$('play').addEventListener('click', () => {
  if (racer.getDate() === dates.at(-1)) racer.skipBack();
  racer.toggle();
});
$('reset').addEventListener('click', () => racer.skipBack());
$('scrub').addEventListener('input', () => {
  racer.pause();
  racer.setDate(dates[Number($('scrub').value)]);
});
$('speed').addEventListener('change', async () => {
  if (!racer || busy) return;
  await racer.changeOptions({
    tickDuration: 1200 / Number($('speed').value)
  });
});
// lesson:controls:end
document.addEventListener('visibilitychange', () => { if (document.hidden) racer?.pause(); });
function route() {
  const hash = location.hash.slice(1);
  const page = !hash || hash.startsWith('intro') ? 'intro' : hash.startsWith('recovery') ? 'recovery' : hash === 'task' ? 'task' : hash === 'extensions' ? 'extensions' : 'terminals';
  document.querySelectorAll('.page').forEach(el => el.hidden = el.id !== page);
  document.querySelectorAll('[data-page]').forEach(el => { el.classList.toggle('active', el.dataset.page === page); if (el.dataset.page === page) el.setAttribute('aria-current','page'); else el.removeAttribute('aria-current'); });
  if (page !== 'terminals') racer?.pause();
  if (page !== 'recovery') pauseRecovery();
}
addEventListener('hashchange', route); route();
const lessonInfo = [
  ['normalize','01','Make the data readable.','Read the quoted CSV with RacingBars’ CSV loader. Convert ReportPeriod into an ISO month and remove the thousands separators before turning counts into numbers. DataExtractDate is an extraction timestamp, not the month being measured.','使用库自带的 CSV 解析器读取带引号的字段；把统计月份转换为 ISO 格式，并移除人数中的千位逗号。不要用数据提取时间作为统计月份。','data-model.js','Source fields → chart fields','normalize.svg','A source record becomes a dated, numeric observation.'],
  ['filter','02','Choose the story’s boundaries.','Apply the start and end months inclusively, then match the movement and travel market. “All” keeps both source categories. Filtering happens before adding counts, so a domestic-arrival race cannot include international departures.','起止月份均包含在区间内。先筛选到达／出发和国内／国际，再进行求和，避免不同类别混入同一结果。','data-model.js','Four conditions → one selected dataset','filter.svg','Every condition must pass before a row enters the race.'],
  ['aggregate','03','One terminal. One month. One value.','Several source rows can belong to the same terminal and month. A Map groups them by date and name, then adds their passenger counts. The result has exactly the date, name and value fields RacingBars needs. Missing combinations are left unestimated.','用“月份 + 航站楼”作为唯一键，把筛选后的客流量相加，生成 date、name、value 三个字段。不对缺失组合进行推算。','data-model.js','Selected records → monthly terminal totals','aggregate.svg','Totals include only the source rows that passed the filters.'],
  ['race','04','Let the ranking move.','Pass those monthly totals to race(). RacingBars sorts the bars and animates their positions and lengths between months. A stable color map keeps each terminal recognizable. Before race(), completeFrames() retains all 12 terminal names in every month. Missing records get display-only zero values and an asterisk, keeping their bars at the bottom instead of exiting. makeCumulative: false preserves monthly counts.','race() 根据客流量排序，并在月份之间过渡条形的长度和位置。固定颜色对应航站楼；completeFrames() 为每月保留全部 12 个类别，缺失记录只用零长度占位并标 *，留在底部，不计作真实的零值。展示每月值而非累计值。','app.js','Monthly totals → animated ranking','race.svg','The axis adapts each month; compare labeled values across time.'],
  ['controls','05','Put time in the reader’s hands.','The play button toggles the race. The timeline pauses it and jumps to an exact month with setDate(). Speed changes the time spent on each month: 1× is 1,200 ms, 2× is 600 ms, and 4× is 300 ms. It never changes the passenger counts.','播放按钮控制动画；拖动时间轴会暂停并跳到指定月份。倍速只改变每个月的播放时长，不会改变数据。默认暂停，读者自行开始。','app.js','Reader input → RacingBars API','controls.svg','Reset returns to the first month in the applied selection.']
];
async function lessons() {
  const sources = Object.fromEntries(await Promise.all(['app.js','data-model.js'].map(async file => [file, await (await fetch(file)).text()])));
  for (const [id, number, title, en, zh, file, footer, img, caption] of lessonInfo) {
    const [, needle, count] = excerptSpecs[id];
    const excerpt = extractExcerpt(sources[file], needle, count);
    const code = excerpt.text;
    const article = document.createElement('article'); article.className = 'lesson'; article.id = `lesson-${id}`;
    article.innerHTML = `<div><span class="stepnum">${number}</span><h3>${title}</h3><p>${en}</p><p class="zh" lang="zh-CN">${zh}</p><figure><img src="illustrations/${img}" alt="${footer}" loading="lazy"><figcaption>${caption}</figcaption></figure></div><div class="codepanel"><div class="codehead"><span>${file} · lines ${excerpt.line}–${excerpt.endLine} · excerpt</span></div><pre><code></code></pre><div class="codefoot">${footer} · excerpt only</div></div>`;
    article.querySelector('code').textContent = code;
    $('lessons').append(article);
  }
}
async function init() {
  try {
    rows = normalize(await loadData('./data/lax.csv', 'csv'));
    if (rows.some(row => !Number.isFinite(row.value))) throw new Error('Invalid passenger count');
    const months = [...new Set(rows.map(d => d.date.slice(0,7)))].sort();
    for (const id of ['start','end']) $(id).replaceChildren(...months.map(month => new Option(dateLabel(`${month}-01`),month)));
    $('start').value = months[0]; $('end').value = months.at(-1);
    initRecovery(rows);
    await build();
  } catch (e) { console.error(e); error('Unable to load the dataset. Serve this folder over HTTP (see README), then reload.'); $('line-error').hidden = false; $('line-error').textContent = 'Unable to load the airport data. Please reload the page.'; }
}
init(); lessons().catch(e => { console.error(e); $('lessons').textContent = 'The walkthrough could not load. Reload to try again.'; });
