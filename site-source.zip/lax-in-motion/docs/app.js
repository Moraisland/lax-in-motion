import { excerptSpecs, extractExcerpt } from './excerpts.js';
import { race } from './vendor/racing-bars.js';
import { filterRows, completeFrames, dateLabel } from './data-model.js';
import { initRecovery, pauseRecovery } from './recovery.js';
import { loadTerminalRows, terminalTotals, terminalColorMap, markTerminalMissing, updateTerminalTable, updateTerminalMonth } from './terminal-d3.js';
const $ = id => document.getElementById(id);
const fmt = new Intl.NumberFormat('en-US');
const names = ['T1','T2','T3','T4','T5','T6','T7','T8','TBIT','TBIT West Gates','Imperial Terminal','Miscellaneous Terminal'];
const colorMap = terminalColorMap(names, ['#1746aa','#2b78b7','#4c65c6','#5d9ac9','#233b77','#728bc4','#157c96','#548ca6','#2563eb','#769fda','#667b95','#99abc3']);
let racer, rows, chartData, dates = [], active, busy = false;
function settings() { return { start: $('start').value, end: $('end').value, movement: $('movement').value, market: $('market').value }; }
function error(message = '') { $('error').textContent = message; $('error').hidden = !message; }
function annotateMissing() {
  if (!racer) return;
  markTerminalMissing('#race', chartData.filter(d => d.date === racer.getDate()));
}
// The library creates its SVG asynchronously, after race() can already resolve.
new MutationObserver(records => {
  if (records.some(record => [...record.addedNodes].some(node => node.nodeType === 1))) annotateMissing();
}).observe($('race'), { childList: true, subtree: true });
function sync() {
  if (!racer) return;
  const date = racer.getDate();
  const index = dates.indexOf(date);
  updateTerminalMonth('#current', dateLabel(date), racer.isRunning());
  $('scrub').value = Math.max(0, index);
  $('play').textContent = racer.isRunning() ? 'Ⅱ Pause race' : index === dates.length - 1 && dates.length > 1 ? '↺ Replay race' : '▶ Play race';
  $('frameCount').textContent = `${index + 1} / ${dates.length} months`;
  const slice = chartData.filter(d => d.date === date).sort((a, b) => b.value - a.value || a.name.localeCompare(b.name));
  // Names stay stable for RacingBars; the asterisk only changes the visible label.
  annotateMissing();
  const total = slice.reduce((sum, d) => sum + d.value, 0);
  const leaders = slice.filter(d => d.value === slice[0]?.value);
  $('insight').textContent = total > 0 ? `${leaders.map(d => d.name).join(' & ')} ${leaders.length > 1 ? 'lead' : 'leads'} with ${fmt.format(slice[0].value)} movements · ${fmt.format(total)} reported in total.` : 'No positive passenger movements reported for this selection.';
  $('race').setAttribute('aria-label', `${dateLabel(date)}: ${$('insight').textContent} Detailed values are available in the data table below.`);
  $('tableCaption').textContent = `${dateLabel(date)} · ${$('context').textContent}`;
  updateTerminalTable('#dataTable', slice);
}
async function build() {
  if (busy) return;
  const selection = settings();
  if (selection.start > selection.end) { error('Start month must be on or before end month. Your current chart has been kept.'); return; }
  const nextData = terminalTotals(filterRows(rows, selection));
  if (!nextData.length) { error('No source records match this selection. Choose another range or filter.'); return; }
  busy = true; error();
  const controls = [...document.querySelectorAll('#filters select, #filters button, .player button, .player input')];
  controls.forEach(el => el.disabled = true);
  $('apply').textContent = 'Updating…';
  try {
    if (racer) { racer.destroy(); racer = null; }
    chartData = completeFrames(nextData, names); active = selection;
    // lesson:race:start
    racer = await race(chartData, '#race', {
      dataShape: 'long',
      autorun: false,
      topN: 12,
      tickDuration: 1200 / Number($('speed').value),
      colorMap,
      labelsPosition: 'outside', labelsWidth: 180,
      marginLeft: 16, marginRight: 80,
      marginTop: 35, marginBottom: 68,
      minWidth: 580, minHeight: 400,
      dateCounter: 'MMM YYYY',
      valueDecimals: 0, valueLocale: 'en-US',
      makeCumulative: false, fixedScale: false,
      controlButtons: 'none', overlays: 'none',
      mouseControls: false, keyboardControls: false,
      highlightBars: true
    });
    // lesson:race:end
    dates = racer.getAllDates();
    $('scrub').max = dates.length - 1;
    $('rangeStart').textContent = dateLabel(dates[0]);
    $('rangeEnd').textContent = dateLabel(dates.at(-1));
    $('context').textContent = `Monthly passenger movements · ${active.movement === 'All' ? 'Arrivals + departures' : active.movement === 'Arrival' ? 'Arrivals' : 'Departures'} · ${active.market === 'All' ? 'Domestic + international' : active.market}`;
    ['dateChange','play','pause','lastDate'].forEach(event => racer.on(event, sync));
    $('pending').hidden = true;
    sync();
  } catch (e) { console.error(e); error('The chart could not load. Please reload the page or download the source CSV below.'); }
  finally {
    busy = false; controls.forEach(el => el.disabled = false);
    $('play').disabled = !racer || dates.length < 2;
    $('reset').disabled = !racer;
    $('scrub').disabled = !racer || dates.length < 2;
    $('apply').textContent = 'Apply filters ↗';
  }
}
$('filters').addEventListener('submit', event => { event.preventDefault(); build(); });
['start','end','movement','market'].forEach(id => $(id).addEventListener('change', () => {
  $('pending').hidden = false; racer?.pause(); sync();
}));
// lesson:controls:start
$('play').addEventListener('click', () => {
  if (racer.getDate() === dates.at(-1)) racer.skipBack();
  racer.toggle();
});
$('reset').addEventListener('click', () => racer.skipBack());
$('scrub').addEventListener('input', () => {
  racer.pause();
  racer.setDate(dates[Number($('scrub').value)]);
});
$('speed').addEventListener('change', async () => {
  if (!racer || busy) return;
  await racer.changeOptions({
    tickDuration: 1200 / Number($('speed').value)
  });
});
// lesson:controls:end
document.addEventListener('visibilitychange', () => { if (document.hidden) racer?.pause(); });
function route() {
  const hash = location.hash.slice(1);
  const page = !hash || hash.startsWith('intro') ? 'intro' : hash.startsWith('recovery') ? 'recovery' : hash === 'task' ? 'task' : hash === 'extensions' ? 'extensions' : 'terminals';
  document.querySelectorAll('.page').forEach(el => el.hidden = el.id !== page);
  document.querySelectorAll('[data-page]').forEach(el => { el.classList.toggle('active', el.dataset.page === page); if (el.dataset.page === page) el.setAttribute('aria-current','page'); else el.removeAttribute('aria-current'); });
  if (page !== 'terminals') racer?.pause();
  if (page !== 'recovery') pauseRecovery();
}
addEventListener('hashchange', route); route();
const lessonInfo = [
  ['d3load','01','Read a real CSV with D3.','d3.csv reads the quoted CSV and calls terminalRow for each record. The converter uses d3.utcParse and d3.utcFormat for ReportPeriod and turns comma-separated counts into numbers. This is the data-loading path used by the terminal chart.','d3.csv 读取真实 CSV，并逐行调用转换函数。统计月份由 D3 日期工具解析，人数转换为数字；这段代码确实参与本图的数据加载。','terminal-d3.js','CSV → typed monthly observations','normalize.svg','ReportPeriod is the month being measured; DataExtractDate is not.'],
  ['d3sum','02','Group by month, then terminal.','d3.rollups groups the filtered observations by date and terminal. d3.sum adds the passenger counts in each group. Arrival/departure and domestic/international filters still run first. The grouped results become the monthly values passed to RacingBars.','先筛选，再用 d3.rollups 按月份和航站楼分组，d3.sum 求和。结果作为 RacingBars 的输入；缺失数据仍单独标记。','terminal-d3.js','Selected records → monthly terminal totals','aggregate.svg','The same source counts produce the same totals as before.'],
  ['d3color','03','Give every terminal a stable color.','d3.scaleOrdinal maps terminal identities to the original color palette. An explicit domain keeps the mapping independent of rank or filter order. The resulting colorMap is passed to race(), so the bar colors stay exactly as before.','d3.scaleOrdinal 将固定航站楼名称映射到原有色板。颜色由名称决定，不随排名或筛选顺序变化，并实际传入 race()。','terminal-d3.js','Terminal identity → consistent bar color','d3-colors.svg','Rank may change. The color for T1 does not.'],
  ['d3join','04','Keep identities when data updates.','This keyed D3 data join updates the chart’s existing “Data for this month” table. The terminal name is the key: rows are reused and reordered when the ranking changes. The same module also selects the chart’s SVG labels to mark missing observations with an asterisk.','这里用航站楼名称作为 key，更新图表下方原有的月度数据表：复用并重排每一行。同一模块还用 D3 选择 SVG 标签，为缺失记录标星号。','terminal-d3.js','Monthly frame → keyed table rows','d3-join.svg','This join controls the data table; RacingBars owns the SVG bar join.'],
  ['d3transition','05','Make a change of month noticeable.','This D3 transition gently restores the existing month heading from 55% to full opacity during playback. duration sets 240 ms; easeCubicOut slows the end of the change. It does not interpolate dates or invent observations. Reduced-motion mode skips this cue. RacingBars continues to animate bar lengths and ranks using its own D3 transitions.','播放时，D3 将原有月份标题的不透明度从 55% 平滑恢复到 100%。duration 控制时长，easeCubicOut 控制缓动；不对日期或真实数据插值。条形长度与排名仍由 RacingBars 内部的 D3 过渡负责。','terminal-d3.js','New monthly frame → subtle D3 transition','d3-transition.svg','The layout and chart styling are preserved; only the month-change cue is added.']
];
async function lessons() {
  const sources = Object.fromEntries(await Promise.all(['terminal-d3.js'].map(async file => [file, await (await fetch(file)).text()])));
  for (const [id, number, title, en, zh, file, footer, img, caption] of lessonInfo) {
    const [, needle, count] = excerptSpecs[id];
    const excerpt = extractExcerpt(sources[file], needle, count);
    const code = excerpt.text;
    const article = document.createElement('article'); article.className = 'lesson'; article.id = `lesson-${id}`;
    article.innerHTML = `<div><span class="stepnum">${number}</span><h3>${title}</h3><p>${en}</p><p class="zh" lang="zh-CN">${zh}</p><figure><img src="illustrations/${img}" alt="${footer}" loading="lazy"><figcaption>${caption}</figcaption></figure></div><div class="codepanel"><div class="codehead"><span>${file} · lines ${excerpt.line}–${excerpt.endLine} · excerpt</span></div><pre><code></code></pre><div class="codefoot">${footer} · excerpt only</div></div>`;
    article.querySelector('code').textContent = code;
    $('lessons').append(article);
  }
}
async function init() {
  try {
    rows = await loadTerminalRows('./data/lax.csv');
    if (rows.some(row => !Number.isFinite(row.value))) throw new Error('Invalid passenger count');
    const months = [...new Set(rows.map(d => d.date.slice(0,7)))].sort();
    for (const id of ['start','end']) $(id).replaceChildren(...months.map(month => new Option(dateLabel(`${month}-01`),month)));
    $('start').value = months[0]; $('end').value = months.at(-1);
    initRecovery(rows);
    await build();
  } catch (e) { console.error(e); error('Unable to load the dataset. Serve this folder over HTTP (see README), then reload.'); $('line-error').hidden = false; $('line-error').textContent = 'Unable to load the airport data. Please reload the page.'; }
}
init(); lessons().catch(e => { console.error(e); $('lessons').textContent = 'The walkthrough could not load. Reload to try again.'; });
