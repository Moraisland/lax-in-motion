import { excerptSpecs, extractExcerpt } from './excerpts.js';
import { airportMonths, baselineChange, recoverySummary, seriesDefinitions } from './recovery-model.js';
import { dateLabel } from './data-model.js';
const $ = id => document.getElementById(id);
const ns = 'http://www.w3.org/2000/svg';
const number = new Intl.NumberFormat('en-US');
const percent = n => n === null ? 'No baseline' : `${n > 0 ? '+' : ''}${n.toFixed(1)}%`;
let months = [], series = [], position = 0, running = false, frame = 0, lastTime = null, inspected = null;
let paths = [], dots = [], cursor, shade, svg, ceiling;
const plot = { left: 72, right: 1010, top: 60, bottom: 405 };
const x = i => plot.left + i / (months.length - 1) * (plot.right - plot.left);
const y = value => plot.bottom - value / ceiling * (plot.bottom - plot.top);
function node(tag, attrs = {}, text = '') {
  const el = document.createElementNS(ns, tag);
  for (const [key, value] of Object.entries(attrs)) el.setAttribute(key, value);
  if (text) el.textContent = text;
  return el;
}
export function pauseRecovery() {
  running = false; cancelAnimationFrame(frame); lastTime = null;
  if ($('line-play')) $('line-play').textContent = position >= months.length - 1 ? '↺ Replay story' : '▶ Play story';
}
// recovery:path:start
function linePath(key, progress) {
  const index = Math.floor(progress);
  const fraction = progress - index;
  const points = months.slice(0, index + 1)
    .map((month, i) => `${i ? 'L' : 'M'}${x(i)},${y(month[key])}`);
  if (fraction > 0 && index < months.length - 1) {
    const value = months[index][key] +
      (months[index + 1][key] - months[index][key]) * fraction;
    points.push(`L${x(progress)},${y(value)}`);
  }
  return points.join(' ');
}
// recovery:path:end
function updateReadout(index) {
  const month = months[index];
  $('line-date').textContent = dateLabel(month.date);
  $('line-values').replaceChildren(...series.map(s => {
    const item = document.createElement('div'); item.className = 'line-value';
    item.style.setProperty('--series', s.color);
    const label = document.createElement('span'); label.textContent = s.label;
    const value = document.createElement('b'); value.textContent = number.format(month[s.key]);
    const baseline = document.createElement('small'); baseline.textContent = month.date.startsWith('2019') ? '2019 reference month' : `${percent(baselineChange(months, month, s.key))} vs same month in 2019`;
    item.append(label, value, baseline); return item;
  }));
  $('line-phase').textContent = month.date < '2020-03-01' ? 'Before the disruption' : month.date < '2021-01-01' ? 'The 2020 shock' : 'The recovery, month by month';
  $('line-progress').textContent = `${Math.floor(position) + 1} / ${months.length} months revealed`;
  svg.setAttribute('aria-label', `${dateLabel(month.date)}. ${series.map(s => `${s.label}: ${number.format(month[s.key])}`).join('. ')}. Use left and right arrow keys to inspect revealed months.`);
}
function draw() {
  const index = Math.floor(position), fraction = position - index;
  series.forEach((s, i) => {
    paths[i].setAttribute('d', linePath(s.key, position));
    const a = months[index][s.key], b = months[Math.min(index + 1, months.length - 1)][s.key];
    dots[i].setAttribute('cx', x(position)); dots[i].setAttribute('cy', y(a + (b - a) * fraction));
  });
  shade.setAttribute('x', x(position)); shade.setAttribute('width', Math.max(0, plot.right - x(position)));
  const focus = inspected ?? index;
  cursor.setAttribute('x1', x(focus)); cursor.setAttribute('x2', x(focus));
  updateReadout(focus);
}
// recovery:animate:start
function animate(timestamp) {
  if (!running) return;
  if (lastTime !== null) {
    const duration = 550 / Number($('line-speed').value);
    position = Math.min(months.length - 1,
      position + (timestamp - lastTime) / duration);
  }
  lastTime = timestamp;
  draw();
  if (position < months.length - 1) frame = requestAnimationFrame(animate);
  else pauseRecovery();
}
// recovery:animate:end
function buildChart() {
  pauseRecovery(); inspected = null;
  series = seriesDefinitions[$('line-mode').value];
  ceiling = Math.ceil(Math.max(...months.map(d => d.total)) / 2000000) * 2000000;
  svg.replaceChildren(); paths = []; dots = [];
  svg.append(node('title', {}, 'LAX monthly passenger movements, January 2019 to October 2023'));
  svg.append(node('desc', {}, 'A fixed-scale line chart. Solid blue and dashed teal distinguish comparison series. All terminal categories are summed.'));
  svg.append(node('rect', { x: plot.left, y: plot.top, width: x(14) - plot.left, height: plot.bottom - plot.top, fill: '#f4f8fe' }));
  for (let value = 0; value <= ceiling; value += 2000000) {
    svg.append(node('line', { x1: plot.left, x2: plot.right, y1: y(value), y2: y(value), stroke: '#e1e9f3' }));
    svg.append(node('text', { x: plot.left - 16, y: y(value) + 4, 'text-anchor': 'end', class: 'axislabel' }, `${value / 1000000}M`));
  }
  svg.append(node('text', { x: plot.left, y: 22, class: 'axislabel' }, 'MONTHLY PASSENGER MOVEMENTS'));
  for (const i of [0, 12, 24, 36, 48, 57]) svg.append(node('text', { x: x(i), y: 433, 'text-anchor': i === 57 ? 'end' : 'middle', class: 'axislabel' }, i === 57 ? 'OCT 2023' : months[i].date.slice(0, 4)));
  // Historical context markers do not assert a causal effect size.
  for (const [index, text, anchor] of [[14, 'MAR 2020 · Pandemic characterized', 'start'], [52, 'MAY 2023 · Global emergency ends', 'end']]) {
    svg.append(node('line', { x1: x(index), x2: x(index), y1: 40, y2: plot.bottom, stroke: '#96aecf', 'stroke-dasharray': '4 5' }));
    svg.append(node('text', { x: x(index) + (anchor === 'start' ? 7 : -7), y: 42, 'text-anchor': anchor, class: 'eventlabel' }, text));
  }
  series.forEach(s => {
    const path = node('path', { fill: 'none', stroke: s.color, 'stroke-width': 3.5, 'stroke-linejoin': 'round', 'stroke-linecap': 'round', ...(s.dashed ? { 'stroke-dasharray': '8 6' } : {}) });
    paths.push(path); svg.append(path);
    const dot = node('circle', { r: 5, fill: 'white', stroke: s.color, 'stroke-width': 3 }); dots.push(dot);
  });
  shade = node('rect', { y: plot.top, height: plot.bottom - plot.top, fill: '#ffffff', opacity: '.45', 'pointer-events': 'none' }); svg.append(shade);
  cursor = node('line', { y1: plot.top, y2: plot.bottom, stroke: '#99aecb', 'stroke-dasharray': '3 4', 'pointer-events': 'none' }); svg.append(cursor, ...dots);
  $('line-legend').replaceChildren(...series.map(s => {
    const el = document.createElement('span'); el.className = s.dashed ? 'dashed' : ''; el.style.setProperty('--series', s.color); el.textContent = s.label; return el;
  }));
  $('line-title').textContent = { total: 'One airport. An unprecedented interruption.', market: 'Two markets. Different paths back.', movement: 'Arriving and departing, almost in step.' }[$('line-mode').value];
  $('line-subtitle').textContent = $('line-mode').value === 'movement' ? 'Arrivals and departures are close; the dashed line and exact values help distinguish them.' : 'All terminals combined · Monthly counts · Fixed axes across all three views';
  updateTable(); draw();
}
function updateTable() {
  $('line-table-head').replaceChildren(...['Month', ...series.map(s => s.label)].map(label => { const th = document.createElement('th'); th.textContent = label; th.scope = 'col'; return th; }));
  $('line-table-body').replaceChildren(...months.map(month => {
    const tr = document.createElement('tr');
    for (const value of [dateLabel(month.date), ...series.map(s => number.format(month[s.key]))]) { const td = document.createElement('td'); td.textContent = value; tr.append(td); }
    return tr;
  }));
}
export function initRecovery(rows) {
  months = airportMonths(rows); if (!months.length) return;
  svg = $('recovery-svg'); position = months.length - 1;
  const summary = recoverySummary(months);
  $('recovery-annual').textContent = percent(summary.annualDrop);
  $('recovery-low').textContent = percent(summary.lowChange);
  $('recovery-low-month').textContent = `${dateLabel(summary.low.date)} vs ${dateLabel('2019' + summary.low.date.slice(4))}`;
  $('recovery-latest').textContent = `${(100 + summary.latestChange).toFixed(1)}%`;
  $('recovery-low-copy').textContent = `${dateLabel(summary.low.date)} recorded ${number.format(summary.low.total)} passenger movements, the lowest month from 2020 through October 2023 in this dataset.`;
  $('recovery-latest-copy').textContent = `By ${dateLabel(summary.latest.date)}, monthly traffic was ${number.format(summary.latest.total)} movements: ${(100 + summary.latestChange).toFixed(1)}% of the same month in 2019.`;
  buildChart();
  ['line-play','line-reset','line-full','line-mode','line-speed'].forEach(id => $(id).disabled = false);
  $('line-mode').addEventListener('change', buildChart);
  $('line-play').addEventListener('click', () => {
    if (running) return pauseRecovery();
    if (position >= months.length - 1) position = 0;
    inspected = null; running = true; lastTime = null; $('line-play').textContent = 'Ⅱ Pause story';
    frame = requestAnimationFrame(animate);
  });
  $('line-reset').addEventListener('click', () => { pauseRecovery(); position = 0; inspected = null; draw(); $('line-play').textContent = '▶ Play story'; });
  $('line-full').addEventListener('click', () => { pauseRecovery(); position = months.length - 1; inspected = null; draw(); $('line-play').textContent = '↺ Replay story'; });
  svg.addEventListener('pointermove', event => {
    if (running) return;
    const p = svg.createSVGPoint(); p.x = event.clientX; p.y = event.clientY;
    const local = p.matrixTransform(svg.getScreenCTM().inverse());
    inspected = Math.max(0, Math.min(Math.floor(position), Math.round((local.x - plot.left) / (plot.right - plot.left) * (months.length - 1)))); draw();
  });
  svg.addEventListener('pointerleave', () => { inspected = null; draw(); });
  svg.addEventListener('keydown', event => {
    if (!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
    event.preventDefault(); pauseRecovery();
    inspected = event.key === 'Home' ? 0 : event.key === 'End' ? Math.floor(position) : Math.max(0, Math.min(Math.floor(position), (inspected ?? Math.floor(position)) + (event.key === 'ArrowRight' ? 1 : -1)));
    draw();
  });
  document.addEventListener('visibilitychange', () => { if (document.hidden) pauseRecovery(); });
  renderLessons().catch(() => { $('recovery-lessons').textContent = 'Reload to load the code walkthrough.'; });
}
async function renderLessons() {
  const definitions = [
    ['sum','01','Sum the airport, not the terminals.','Add every terminal into a monthly airport total. At the same time, keep separate domestic/international and arrival/departure sums. Switching the view selects one or two series from these same monthly records.','将所有航站楼按月份求和，同时保留国内／国际和到达／出发两个维度。切换视图只是选择不同序列，不会重复计算总量。','recovery-model.js','airport-sum.svg'],
    ['path','02','Turn monthly values into a line.','Map month positions to the x-axis and passenger counts to the y-axis. M starts the SVG path; L connects the next point. A fractional final segment makes the line advance smoothly. Between-month values are visual interpolation, not extra observations.','月份映射到横轴，客流量映射到纵轴；M 是起点，L 连接下一个点。末段的线性插值产生平滑动画，但不代表额外观测数据。','recovery.js','line-path.svg'],
    ['animate','03','Reveal the story with time.','requestAnimationFrame supplies the clock. Elapsed time advances a fractional month, and draw() updates the paths and moving dots. The axes stay fixed, so the recovery cannot appear stronger just because the chart rescales.','requestAnimationFrame 提供时钟，根据经过的毫秒推进月份并重绘折线与圆点。坐标轴固定，避免自动缩放夸大恢复程度。','recovery.js','line-clock.svg'],
    ['baseline','04','Compare like with like.','Compare each month with the same calendar month in 2019. This keeps a summer month from being compared with a quieter winter month. The percentage is descriptive; it does not isolate the effect of any single policy or event.','使用 2019 年同月作为基准，减少旺季与淡季错配。该比例描述客流变化，不用于推断某项政策或事件的独立因果效应。','recovery-model.js','line-baseline.svg']
  ];
  const sources = Object.fromEntries(await Promise.all(['recovery.js','recovery-model.js'].map(async file => [file, await (await fetch(file)).text()])));
  for (const [id,n,title,en,zh,file,img] of definitions) {
    const [, needle, count] = excerptSpecs[id];
    const excerpt = extractExcerpt(sources[file], needle, count);
    const code = excerpt.text;
    const article = document.createElement('article'); article.className = 'lesson';
    article.innerHTML = `<div><span class="stepnum">${n}</span><h3>${title}</h3><p>${en}</p><p class="zh" lang="zh-CN">${zh}</p><figure><img src="illustrations/${img}" alt="${title}" loading="lazy"></figure></div><div class="codepanel"><div class="codehead"><span>${file} · lines ${excerpt.line}–${excerpt.endLine} · excerpt</span></div><pre><code></code></pre><div class="codefoot">Actual source excerpt · surrounding implementation omitted</div></div>`;
    article.querySelector('code').textContent = code;
    $('recovery-lessons').append(article);
  }
}
