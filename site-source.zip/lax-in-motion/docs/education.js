import { loadData } from './vendor/racing-bars.js';
import { extractExcerpt, excerptSpecs } from './excerpts.js';
const $ = id => document.getElementById(id);
const slider = $('tween-progress');
function updateTween() {
  const t = Number(slider.value) / 100;
  const value = 100 + (200 - 100) * t;
  $('tween-bar').style.width = `${value / 2}%`;
  $('tween-value').textContent = `t = ${t.toFixed(2)} · value = ${Math.round(value)}`;
}
slider.addEventListener('input', updateTween); updateTween();
for (const button of document.querySelectorAll('[data-copy]')) {
  button.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText($(button.dataset.copy).innerText); button.textContent = 'Copied'; }
    catch { button.textContent = 'Select the text to copy'; }
  });
}
fetch('app.js').then(response => { if (!response.ok) throw new Error('Source unavailable'); return response.text(); }).then(source => {
  const [, needle, count] = excerptSpecs.race;
  const excerpt = extractExcerpt(source, needle, count);
  $('racing-actual').textContent = excerpt.text;
  $('racing-actual').closest('.codepanel').querySelector('.codehead').textContent = `app.js · lines ${excerpt.line}–${excerpt.endLine} · selected fragment`;
}).catch(() => { $('racing-actual').textContent = 'Open app.js to inspect the RacingBars import and race() call.'; });
fetch('excerpts/racingbars-transition.txt').then(r => { if (!r.ok) throw new Error('Missing excerpt'); return r.text(); }).then(text => { $('d3-actual').textContent = text; }).catch(() => { $('d3-actual').textContent = 'Source excerpt unavailable. Reload to try again.'; });

loadData('data/lax.csv', 'csv').then(rows => {
  const columns = ['DataExtractDate','ReportPeriod','Terminal','Arrival_Departure','Domestic_International','Passenger_Count'];
  let page = 0;
  const size = 25;
  const cell = (tag, text) => { const el = document.createElement(tag); el.textContent = text; return el; };
  const letters = document.createElement('tr'); letters.className = 'sheet-letters';
  letters.append(...['','A','B','C','D','E','F'].map(text => cell('th',text)));
  const header = document.createElement('tr'); header.append(cell('th','1'),...columns.map(text=>cell('th',text)));
  $('raw-data-head').replaceChildren(letters,header);
  function renderRows() {
    const start = page * size;
    $('raw-data-body').replaceChildren(...rows.slice(start,start+size).map((row,i)=>{
      const tr=document.createElement('tr'); tr.append(cell('th',String(start+i+2)),...columns.map(key=>cell('td',row[key]))); return tr;
    }));
    $('raw-page').textContent = `Records ${start+1}–${Math.min(start+size,rows.length)} of ${rows.length.toLocaleString('en-US')}`;
    $('raw-prev').disabled = page === 0;
    $('raw-next').disabled = start+size >= rows.length;
  }
  $('raw-prev').addEventListener('click',()=>{ if(page>0){page--;renderRows();} });
  $('raw-next').addEventListener('click',()=>{ if((page+1)*size<rows.length){page++;renderRows();} });
  renderRows();
}).catch(()=>{ $('raw-page').textContent='Unable to load the original CSV. Reload to try again.'; });
