// Each teaching fragment is extracted from a file actually shipped with the site.
export const excerptSpecs = {
  normalize: ['data-model.js', "      name: row.Terminal,", 4],
  filter: ['data-model.js', "    row.date >=", 3],
  aggregate: ['data-model.js', '    const key =', 3],
  race: ['app.js', '      tickDuration:', 3],
  controls: ['app.js', '  racer.pause();', 2],
  sum: ['recovery-model.js', '    month.total +=', 3],
  path: ['recovery.js', '    const value = months[index]', 3],
  animate: ['recovery.js', '    const duration = 550', 3],
  baseline: ['recovery-model.js', '  const baseline = months.find', 3],
};
export function extractExcerpt(source, needle, count) {
  const lines = source.split(/\r?\n/);
  const index = lines.findIndex(line => line.startsWith(needle));
  if (index < 0) throw new Error(`Excerpt anchor not found: ${needle}`);
  const selected = lines.slice(index, index + count);
  const indent = Math.min(...selected.filter(line => line.trim()).map(line => line.match(/^ */)[0].length));
  return { text: selected.map(line => line.slice(indent)).join('\n'), line: index + 1, endLine: index + count };
}
