import { aggregate, completeFrames, filterRows } from './data-model.js';
export const terminalNames = ['T1','T2','T3','T4','T5','T6','T7','T8','TBIT','TBIT West Gates','Imperial Terminal','Miscellaneous Terminal'];
export const terminalColors = Object.fromEntries(terminalNames.map((name, i) => [name, ['#e4474a','#f27d24','#d6ac14','#8cba2a','#2b9e50','#149b81','#139fbd','#347bd1','#5856c9','#8754c9','#bf4db0','#dd5285'][i]]));
export function taskFrames(rows, movement, market) {
  return completeFrames(aggregate(filterRows(rows, { start:'2019-01', end:'2019-12', movement, market })), terminalNames);
}
export function taskSummary(data, date) {
  const frame = data.filter(row => row.date === date);
  const total = frame.reduce((sum, row) => sum + row.value, 0);
  const max = Math.max(0, ...frame.map(row => row.value));
  return { total, leaders: max > 0 ? frame.filter(row => row.value === max).map(row => row.name) : [], missing: frame.filter(row => row.missing).map(row => row.name) };
}
