import { aggregate, completeFrames, filterRows } from './data-model.js';
export const terminalNames = ['T1','T2','T3','T4','T5','T6','T7','T8','TBIT','TBIT West Gates','Imperial Terminal','Miscellaneous Terminal'];
export const terminalColors = Object.fromEntries(terminalNames.map((name, i) => [name, ['#1746aa','#2b78b7','#4c65c6','#5d9ac9','#233b77','#728bc4','#157c96','#548ca6','#2563eb','#769fda','#667b95','#99abc3'][i]]));
export function taskFrames(rows, movement, market) {
  return completeFrames(aggregate(filterRows(rows, { start:'2019-01', end:'2019-12', movement, market })), terminalNames);
}
export function taskSummary(data, date) {
  const frame = data.filter(row => row.date === date);
  const total = frame.reduce((sum, row) => sum + row.value, 0);
  const max = Math.max(0, ...frame.map(row => row.value));
  return { total, leaders: max > 0 ? frame.filter(row => row.value === max).map(row => row.name) : [], missing: frame.filter(row => row.missing).map(row => row.name) };
}
