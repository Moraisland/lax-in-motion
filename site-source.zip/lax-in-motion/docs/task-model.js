import { aggregate, completeFrames, filterRows } from './data-model.js';
export const terminalNames = ['T1','T2','T3','T4','T5','T6','T7','T8','TBIT','TBIT West Gates','Imperial Terminal','Miscellaneous Terminal'];
export const terminalColors = Object.fromEntries(terminalNames.map((name, i) => [name, ['#e4474a','#f27d24','#d6ac14','#ed72b0','#308b64','#8a5841','#16a9d0','#347bd1','#5644b5','#a078d1','#b52e81','#7d899b'][i]]));
export function taskFrames(rows, movement, market) {
  return completeFrames(aggregate(filterRows(rows, { start:'2019-01', end:'2019-12', movement, market })), terminalNames);
}
export function taskSummary(data, date) {
  const frame = data.filter(row => row.date === date);
  const total = frame.reduce((sum, row) => sum + row.value, 0);
  const max = Math.max(0, ...frame.map(row => row.value));
  return { total, leaders: max > 0 ? frame.filter(row => row.value === max).map(row => row.name) : [], missing: frame.filter(row => row.missing).map(row => row.name) };
}
