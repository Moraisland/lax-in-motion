export const seriesDefinitions = {
  total: [{ key: 'total', label: 'All passenger movements', color: '#2563eb' }],
  market: [{ key: 'domestic', label: 'Domestic', color: '#2563eb' }, { key: 'international', label: 'International', color: '#138a97', dashed: true }],
  movement: [{ key: 'arrival', label: 'Arrivals', color: '#2563eb' }, { key: 'departure', label: 'Departures', color: '#138a97', dashed: true }]
};
// recovery:sum:start
export function airportMonths(rows) {
  const months = new Map();
  for (const row of rows) {
    if (row.date < '2019-01-01' || row.date > '2023-10-01') continue;
    const month = months.get(row.date) ?? {
      date: row.date, total: 0, domestic: 0,
      international: 0, arrival: 0, departure: 0
    };
    month.total += row.value;
    month[row.market.toLowerCase()] += row.value;
    month[row.movement.toLowerCase()] += row.value;
    months.set(row.date, month);
  }
  return [...months.values()].sort((a, b) => a.date.localeCompare(b.date));
}
// recovery:sum:end
// recovery:baseline:start
export function baselineChange(months, month, key) {
  const baseline = months.find(d => d.date === `2019${month.date.slice(4)}`);
  if (!baseline || !baseline[key]) return null;
  return (month[key] / baseline[key] - 1) * 100;
}
// recovery:baseline:end
export function recoverySummary(months) {
  const annual = year => months.filter(d => d.date.startsWith(year)).reduce((sum, d) => sum + d.total, 0);
  const low = months.filter(d => d.date >= '2020-01-01').reduce((a, b) => a.total < b.total ? a : b);
  const latest = months.at(-1);
  return { low, latest, annualDrop: (annual('2020') / annual('2019') - 1) * 100, lowChange: baselineChange(months, low, 'total'), latestChange: baselineChange(months, latest, 'total') };
}
