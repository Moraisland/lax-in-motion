import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { normalize, filterRows, aggregate, completeFrames } from '../docs/data-model.js';
// Parse this source's quoted fields independently of the app's CSV loader.
const lines = readFileSync(new URL('../docs/data/lax.csv', import.meta.url),'utf8').trim().split(/\r?\n/);
const parse = line => [...line.matchAll(/"((?:[^"]|"")*)"(?:,|$)/g)].map(m => m[1].replaceAll('""','"'));
const headers = parse(lines.shift());
const source = lines.map(line => Object.fromEntries(parse(line).map((value,i) => [headers[i],value])));
const rows = normalize(source);
test('every frame keeps all terminal identities; missing and reported zero remain distinct', () => {
  const names = [...new Set(rows.map(row => row.name))];
  for (const movement of ['All','Arrival','Departure']) for (const market of ['All','Domestic','International']) {
    const totals = aggregate(filterRows(rows,{start:'2006-01',end:'2023-10',movement,market}));
    const frames = completeFrames(totals,names);
    assert.equal(frames.length,214 * 12);
    assert.equal(frames.reduce((sum,row) => sum+row.value,0),totals.reduce((sum,row) => sum+row.value,0));
    for (const date of new Set(frames.map(row => row.date))) {
      const frame = frames.filter(row => row.date === date);
      assert.equal(new Set(frame.map(row => row.name)).size,12);
      assert.ok(frame.filter(row => row.missing).every(row => row.value === 0));
    }
  }
  assert.deepEqual(completeFrames([{date:'2020-01-01',name:'T1',value:0}],['T1','T2']),[
    {date:'2020-01-01',name:'T1',value:0,missing:false},
    {date:'2020-01-01',name:'T2',value:0,missing:true}
  ]);
});
test('source coverage, uniqueness and valid counts', () => {
  assert.equal(rows.length,7883);
  assert.equal(new Set(rows.map(r => `${r.date}|${r.name}|${r.movement}|${r.market}`)).size,7883);
  const dates = [...new Set(rows.map(r => r.date))].sort();
  assert.equal(dates.length,214); assert.equal(dates[0],'2006-01-01'); assert.equal(dates.at(-1),'2023-10-01');
  for (let i=1;i<dates.length;i++) { const prev = new Date(dates[i-1]); prev.setUTCMonth(prev.getUTCMonth()+1); assert.equal(prev.toISOString().slice(0,10),dates[i]); }
  assert.ok(rows.every(r => Number.isSafeInteger(r.value) && r.value >= 0));
});
test('all nine movement / market combinations reconcile with original source', () => {
  for (const movement of ['All','Arrival','Departure']) for (const market of ['All','Domestic','International']) {
    const filtered = filterRows(rows,{start:'2006-01',end:'2023-10',movement,market});
    const actual = aggregate(filtered);
    const expected = source.filter(r => (movement === 'All' || r.Arrival_Departure === movement) && (market === 'All' || r.Domestic_International === market)).reduce((n,r) => n+Number(r.Passenger_Count.replaceAll(',','')),0);
    assert.equal(actual.reduce((n,r) => n+r.value,0),expected);
    assert.equal(new Set(actual.map(r => `${r.date}|${r.name}`)).size,actual.length);
  }
});
test('month boundaries are inclusive; missing records are not imputed', () => {
  const filtered = filterRows(rows,{start:'2021-04',end:'2021-04',movement:'Departure',market:'Domestic'});
  assert.ok(filtered.every(r => r.date === '2021-04-01'));
  assert.equal(aggregate(filtered).find(r => r.name === 'T1').value,160413);
  assert.deepEqual(aggregate([]),[]);
  assert.equal(filterRows(rows,{start:'2023-10',end:'2006-01',movement:'All',market:'All'}).length,0);
});
