import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { normalize } from '../docs/data-model.js';
import { airportMonths, baselineChange, recoverySummary } from '../docs/recovery-model.js';
const lines = readFileSync(new URL('../docs/data/lax.csv',import.meta.url),'utf8').trim().split(/\r?\n/);
const parse = line => [...line.matchAll(/"((?:[^"]|"")*)"(?:,|$)/g)].map(m => m[1].replaceAll('""','"'));
const header = parse(lines.shift());
const rows = normalize(lines.map(line => Object.fromEntries(parse(line).map((v,i) => [header[i],v]))));
const months = airportMonths(rows);
test('fixed 58-month window; each monthly split reconciles exactly to all source records', () => {
  assert.equal(months.length,58); assert.equal(months[0].date,'2019-01-01'); assert.equal(months.at(-1).date,'2023-10-01');
  for (const m of months) {
    assert.equal(m.total,rows.filter(r=>r.date===m.date).reduce((sum,r)=>sum+r.value,0));
    assert.equal(m.domestic+m.international,m.total);
    assert.equal(m.arrival+m.departure,m.total);
    for (const [field,dimension,label] of [['domestic','market','Domestic'],['international','market','International'],['arrival','movement','Arrival'],['departure','movement','Departure']]) {
      assert.equal(m[field],rows.filter(r=>r.date===m.date && r[dimension]===label).reduce((sum,r)=>sum+r.value,0));
    }
  }
});
test('baseline matches calendar month, not annual or previous-month totals', () => {
  const oct = months.at(-1), reference = months.find(m=>m.date==='2019-10-01');
  for (const key of ['total','domestic','international','arrival','departure']) assert.equal(baselineChange(months,oct,key),(oct[key]/reference[key]-1)*100);
  assert.equal(baselineChange(months,months[0],'total'),0);
  assert.equal(baselineChange([],oct,'total'),null);
});
test('narrative summaries use complete annual periods and the observed low', () => {
  const summary=recoverySummary(months);
  assert.equal(summary.low.date,'2020-04-01');
  assert.equal(summary.latest.date,'2023-10-01');
  assert.ok(summary.annualDrop<0 && summary.latestChange<0);
  console.log(JSON.stringify(summary));
});
