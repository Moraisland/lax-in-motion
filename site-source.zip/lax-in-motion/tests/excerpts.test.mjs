import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {excerptSpecs,extractExcerpt} from '../docs/excerpts.js';
const read = file => readFileSync(new URL('../docs/'+file,import.meta.url),'utf8');
test('teaching snippets are short verbatim source fragments with accurate line references',()=>{
  for(const [id,[file,needle,count]] of Object.entries(excerptSpecs)){
    const source=read(file),e=extractExcerpt(source,needle,count);
    assert.ok(count<=4,id);
    assert.equal(e.text.split('\n').length,count,id);
    const original=source.split(/\r?\n/).slice(e.line-1,e.endLine).map(x=>x.trim()).join('\n');
    assert.equal(e.text.split('\n').map(x=>x.trim()).join('\n'),original,id);
  }
});
test('D3 example is extracted from the unmodified RacingBars distribution',()=>{
  const meta=JSON.parse(read('excerpts/racingbars-transition-provenance.json'));
  const source=read(meta.source),excerpt=read('excerpts/racingbars-transition.txt');
  assert.equal(excerpt.replace(/[\r\n]/g,''),meta.exactExcerpt);
  assert.ok(source.includes(meta.exactExcerpt));
  assert.equal(createHash('sha256').update(source).digest('hex'),meta.sourceSHA256);
});
test('full prompt and lesson copy buttons are removed; navigation order is correct',()=>{
  const html=read('index.html');
  assert.ok(!html.includes('READY TO USE / THIS LAX DATASET'));
  assert.ok(html.includes('prompt-highlight'));
  assert.ok(html.indexOf('data-page="task"')<html.indexOf('data-page="recovery"'));
  for(const file of ['app.js','recovery.js']) assert.ok(!read(file).includes('clipboard.writeText'));
});
