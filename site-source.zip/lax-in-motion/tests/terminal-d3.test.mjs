import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {normalize,aggregate,filterRows,completeFrames} from '../docs/data-model.js';
import {terminalRow,terminalTotals,terminalColorMap} from '../docs/terminal-d3.js';
const csv=readFileSync(new URL('../docs/data/lax.csv',import.meta.url),'utf8');
const source=globalThis.d3.csvParse(csv);
const oldRows=normalize(source),newRows=source.map(terminalRow);
test('D3 parser preserves every observation and rollups preserve all filter combinations',()=>{
  assert.deepEqual(newRows,oldRows);
  const names=[...new Set(oldRows.map(d=>d.name))];
  for(const movement of ['All','Arrival','Departure']) for(const market of ['All','Domestic','International']){
    const selected=filterRows(newRows,{start:'2006-01',end:'2023-10',movement,market});
    assert.deepEqual(completeFrames(terminalTotals(selected),names),completeFrames(aggregate(selected),names));
  }
});
test('D3 ordinal color map preserves terminal identity and input palette',()=>{
  const colors=terminalColorMap(['T1','T2','TBIT'],['#1746aa','#2b78b7','#2563eb']);
  assert.deepEqual(colors,{T1:'#1746aa',T2:'#2b78b7',TBIT:'#2563eb'});
});
