import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { normalize } from '../docs/data-model.js';
import { taskFrames, taskSummary } from '../docs/task-model.js';
const lines = readFileSync(new URL('../docs/data/lax.csv', import.meta.url),'utf8').trim().split(/\r?\n/);
const parse = line => [...line.matchAll(/"((?:[^"]|"")*)"(?:,|$)/g)].map(m => m[1].replaceAll('""','"'));
const headers = parse(lines.shift());
const source = lines.map(line => Object.fromEntries(parse(line).map((value,i) => [headers[i],value])));
const rows = normalize(source);
test('task counter reconciles all 12 months and all 9 filter combinations with source records', () => {
  for (const movement of ['All','Arrival','Departure']) for (const market of ['All','Domestic','International']) {
    const data = taskFrames(rows,movement,market);
    assert.equal(data.length,144);
    const dates = [...new Set(data.map(row=>row.date))];
    dates.forEach((date,index) => {
      const month = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][index];
      const expected = source.filter(r=>r.ReportPeriod.startsWith(`2019 ${month} `) && (movement==='All'||r.Arrival_Departure===movement) && (market==='All'||r.Domestic_International===market)).reduce((sum,r)=>sum+Number(r.Passenger_Count.replaceAll(',','')),0);
      assert.equal(taskSummary(data,date).total,expected);
    });
  }
});
test('leader example demonstrates the real T1 to T5 handover and handles ties / empty frames', () => {
  const data = taskFrames(rows,'All','Domestic');
  assert.deepEqual(taskSummary(data,'2019-05-01').leaders,['T1']);
  assert.deepEqual(taskSummary(data,'2019-06-01').leaders,['T5']);
  assert.deepEqual(taskSummary([{date:'a',name:'T1',value:10},{date:'a',name:'T2',value:10}],'a').leaders,['T1','T2']);
  assert.deepEqual(taskSummary([],'a').leaders,[]);
});
