# 打开与运行 / Open and run

1. 解压整个文件包，不要只取出 index.html。
2. VS Code → File → Open Folder，打开解压后的项目文件夹。
3. 打开终端，运行 `python -m http.server 4173 --bind 127.0.0.1 --directory docs`。
4. 浏览器打开 http://127.0.0.1:4173/ 。也可用 `npm start`（同样需要 Python）。

网站不需要安装 npm 依赖，也没有构建步骤。不要双击 index.html 使用 file:// 打开：CSV 读取与 JS 模块需要 HTTP。使用 VS Code Live Server 时，请从 docs/index.html 启动。

网页入口是 docs/index.html；CSS 与 JS 都在 docs/，图片与 CSV 也已包含。
新增介绍、How to create、拓展内容的编辑源文件在 content/；修改后运行 `python assemble-content.py`，更新网页中的对应区块。

GitHub Pages：上传项目文件并保留目录结构，然后 Settings → Pages → Deploy from a branch → main → /docs。实际分支名以你的仓库为准。README.md 提供更多说明。

如果此包包含 HANDOFF.md，请让后续 Codex 协作者先读该文件。文件包已包含接手所需的源码和数据，不需要原聊天记录。
