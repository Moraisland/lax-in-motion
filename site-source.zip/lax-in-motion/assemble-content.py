from pathlib import Path
import re
root = Path(__file__).parent
p = root / 'docs/index.html'
s = p.read_text(encoding='utf-8')
for name, anchor, placement in [('intro','<main id="main">','after'),('how-to','<section id="walkthrough"','before'),('extensions','</main>','before')]:
    block = f'<!-- content:{name}:start -->\n{(root / "content" / (name + ".html")).read_text(encoding="utf-8")}\n<!-- content:{name}:end -->'
    pattern = rf'<!-- content:{name}:start -->.*?<!-- content:{name}:end -->'
    if re.search(pattern,s,re.S): s = re.sub(pattern,lambda _: block,s,flags=re.S)
    elif placement == 'after': s = s.replace(anchor,anchor+'\n'+block,1)
    else: s = s.replace(anchor,block+'\n'+anchor,1)
nav = '<nav aria-label="Chapters">' + ''.join(f'<a href="#{page}" data-page="{page}"><small>{n}</small> {label}</a>' for n,page,label in [('00','intro','Introduction'),('01','terminals','Terminal comparison'),('02','task','Task'),('03','recovery','Pandemic & recovery'),('04','extensions','Extensions')]) + '</nav>'
s = re.sub(r'<nav aria-label="Chapters">.*?</nav>',lambda _:nav,s,flags=re.S)
s = s.replace('class="brand" href="#terminals"','class="brand" href="#intro"')
if 'src="education.js"' not in s: s = s.replace('</body>','<script type="module" src="education.js"></script></body>')
p.write_text(s,encoding='utf-8')
