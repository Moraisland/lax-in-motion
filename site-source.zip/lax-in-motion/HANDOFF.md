# LAX in Motion — continuation handoff

## Start here / 接手方式

This is a self-contained static website project. Extract the archive, open this folder as the workspace, and read this document and README.md before making changes. No previous chat, account token, or private conversation history is needed.

给下一位协作者的提示词：

> 请先阅读 HANDOFF.md、README.md 和项目源码，理解现有网站结构。保留数据计算口径、蓝白英文风格和中英双语教学。我接下来希望修改：________。请直接修改对应文件，运行适当的数据校验并检查浏览器效果，最后说明修改内容。

## Current user-approved scope

- Five navigation pages: Introduction (#intro, default landing), Terminal comparison (#terminals), Task (#task, intentionally empty), Pandemic & recovery (#recovery), Extensions (#extensions).
- Intro focuses on meaningful animation and story framing. Meet the data shows the original CSV with original columns, values and row order, 25 records per page, without a field-explanation table. Our two stories covers questions, boundaries, narrative and evidence limits, not chart selection.
- Terminal race: genuine RacingBars 0.5.0, inclusive month selectors, arrival/departure/all, domestic/international/all, speed, play/pause/reset, monthly table. All 12 terminal identities persist in every frame; missing data is a display-only zero placeholder marked *, with Not reported in the table. Never turn missing records into measured zeros.
- Before the terminal code walkthrough: How to create, SVG tweening illustration, interactive interpolation slider, a verified excerpt from the official RacingBars 0.5.0 bundle, a short actual RacingBars configuration excerpt, npm link, Copilot workflow and one highlighted fill-in prompt. The LAX ready-made prompt is removed. Library name and monthly aggregation are bold in the prompts.
- Recovery: native SVG + requestAnimationFrame, whole-airport monthly totals; fixed Jan 2019–Oct 2023 (58 months), no date-range filter. Three modes: total, domestic vs international, arrivals vs departures. Same-month 2019 baseline; fixed axes; exact values and data table. 2023 is partial: no full-year 2023 comparison.
- English primary text; Chinese secondary notes in smaller gray text. Blue/white styling. Task remains empty until requested.
- Extensions links to the user-specified Apache ECharts bar-race example and Flourish ranking gallery. Neither is an application dependency.
- Prepared for GitHub Pages, not publicly deployed. No repository or public URL has been configured. Localhost URLs are previews only.

## File map

| File | Responsibility |
| --- | --- |
| docs/index.html | Fully assembled, directly deployable five-page HTML |
| docs/style.css | Existing visual system, responsive styles and new educational sections |
| docs/app.js | Routing, terminal chart, CSV loading, chapter initialization, actual-code lessons |
| docs/data-model.js | Normalization, terminal filtering, aggregation, stable frames |
| docs/recovery-model.js | Airport totals, series definitions, 2019 baseline comparisons |
| docs/recovery.js | SVG line rendering, animation, inspection, recovery lessons |
| docs/education.js | Tween slider, prompt copying, actual RacingBars code extraction |
| docs/data/lax.csv | Original source CSV, unchanged |
| docs/vendor/racing-bars.js | Official 0.5.0 npm distribution, unmodified |
| docs/vendor/LICENSE-racing-bars | Dependency MIT notice |
| docs/illustrations/ | Local SVG diagrams; schematic illustrations are labeled |
| content/*.html | Authoring fragments for intro, how-to and extensions |
| assemble-content.py | Idempotently inserts those fragments into docs/index.html |
| make-illustrations.py | Rebuilds the original and recovery diagrams; tweening.svg is hand-authored |
| tests/*.test.mjs | Data integrity and chart aggregation checks |

Edit content/*.html for the three new sections, then run `python assemble-content.py`. Other existing sections live directly in docs/index.html. Editing an assembled content block only in index.html will be overwritten next time the assembler runs. Keep the source markers used by code extraction intact.

## Run and verify

- `npm start` or `python -m http.server 4173 --bind 127.0.0.1 --directory docs`.
- Open http://127.0.0.1:4173/ . Do not open HTML via file:// because fetch and ES modules require HTTP.
- No npm install/build is needed. Python runs the static server; Node 20+ runs `npm test`.
- Check all five nav pages, #intro-data, #how-to-create, #recovery-code and #recovery-controls anchor routes.
- Check tween slider 0/50/100 → values 100/150/200, source excerpts, the one template-copy button, and raw-data pagination.
- Check terminal filtering and missing terminals; recovery mode changes and replay. Verify desktop and narrow-screen navigation/overflow.
- Local chart code and CSV require no network after serving; only external documentation links need internet.

## Data facts and pitfalls

7,883 rows; 214 consecutive months Jan 2006–Oct 2023; 12 terminal categories. No duplicate month × terminal × movement × market source keys. Passenger_Count has quoted thousands separators. ReportPeriod is the observation month; DataExtractDate is metadata. Filename suffix 20261026 is not the data endpoint. Counts are movements, not unique people. Sum either market split or movement split; adding both splits together double-counts.

2020 annual change vs 2019: −67.3212%; Apr 2020 monthly total 299,366, −95.8613% vs Apr 2019; Oct 2023 total 6,517,766, −9.4110% vs Oct 2019. These are descriptive changes, not identified causal effects. WHO markers distinguish pandemic characterization in March 2020 from the end of the PHEIC in May 2023.

## Publication and sharing

Serve the docs directory or use GitHub Pages main /docs. Keep relative asset paths so repository subpaths work. Update the existing repository for later revisions; no credentials are included here. The archives contain the deliverable project and context, not the original chat transcript.

## Latest editorial constraints (2026-11-02)

Navigation: 00 Introduction → 01 Terminal comparison → 02 Task → 03 Pandemic & recovery → 04 Extensions. Task stays blank.
All chart lesson copy buttons are removed. Display only 2–4 original source lines per lesson, never whole functions. docs/excerpts.js defines the source anchors and line counts; line numbers are computed from actual source. docs/excerpts/racingbars-transition.txt comes verbatim (newlines added only) from the official vendor bundle, with SHA-256 and exact excerpt recorded in the adjacent provenance JSON. The packaged dependency is unmodified. These are illustrative excerpts of real code, not standalone runnable examples. The complete working application remains in the downloadable source package. Browser source is inherently inspectable; omission from the lesson is not access control.
Only the reusable prompt retains a copy button. Keep it visually prominent; do not restore the completed LAX prompt. Intro raw preview loads docs/data/lax.csv using the bundled CSV loader and preserves literal values and original row order.
New files: docs/excerpts.js, docs/excerpts/*, tests/excerpts.test.mjs. Ten Node tests cover data, excerpt provenance, and editorial constraints.

## Visual refinement (2026-11-02)

`docs/visual-refresh.css` layers clearer section cards, dark blue chapter strips, keyword cards, and a highlighted prompt over the original layout. `docs/illustrations/flight-lines.svg` is a local, subtle decorative background; preserve its low contrast. The reusable prompt now has 13 blanks, including defaults, speed control, playback, missing-data handling and verification. Its Chinese translation is 15 px (14 px on mobile). Keep the library name and monthly aggregation bold. Keyword cards appear beneath both charts, with prompt-building keywords also under the template. Chart behavior and source excerpts are unchanged.

## Completed task examples
Two independent RacingBars examples appear beneath the workshop exercises. docs/tasks.js controls them; docs/task-model.js reuses monthly aggregation. Defaults: 2019 domestic, all movements. Task 1 adds a bottom-right animated total; Task 2 adds a gold outline and TOP 1 badge. Keep full solutions out of lesson copy.
