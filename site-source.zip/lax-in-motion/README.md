# LAX in Motion

An English data story and bilingual chart tutorial, using the exact RacingBars **0.5.0** release. Chapters 1 and 2 are implemented; the Task page is intentionally empty. Chapter 2 uses native SVG and requestAnimationFrame for the animated line chart.

## Preview

From this project directory, run `npm start` (requires Python), then open http://127.0.0.1:4173. Alternatively: `python -m http.server 4173 --bind 127.0.0.1 --directory docs`.

Do not open index.html with file://: module imports and CSV fetching require HTTP.

## Publish with GitHub Pages

1. Create a public GitHub repository and upload this project's files, preserving the `docs` directory.
2. In the repository, choose **Settings → Pages → Build and deployment → Deploy from a branch**.
3. Choose your branch (usually `main`) and the **/docs** folder, then Save.
4. GitHub will show the published URL when deployment completes, typically `https://USERNAME.github.io/REPOSITORY/`.

All site URLs are relative so repository subpaths work. No npm install, build, API key, server backend, or third-party CDN is needed. The CSV and RacingBars distribution are served from the same site. A target repository and authenticated GitHub access are needed to publish; no live deployment is implied by this folder.

## Files

- `docs/index.html`, `style.css`: page layout.
- `docs/app.js`: actual RacingBars configuration, player, source-derived walkthrough.
- `docs/data-model.js`: normalization, filtering and aggregation.
- `docs/illustrations/`: original SVG explanatory diagrams, not simulated data screenshots.
- `docs/data/lax.csv`: exact supplied source, unchanged.
- `docs/vendor/racing-bars.js`: official npm 0.5.0 module; MIT license included.
- `tests/data.test.mjs`: verifies all filter combinations against original source counts, boundaries and data integrity.

## Data methodology

7,883 source rows; 214 consecutive monthly observations, January 2006–October 2023; 12 terminal categories. The filename date is not the observation endpoint. No duplicate keys were found for month × terminal × movement × market. Passenger counts are movements, not unique individuals. Direction/market totals add only matching source rows. Terminal names are preserved, including TBIT West Gates, Miscellaneous Terminal and Imperial Terminal. Missing terminal/month combinations are not imputed in aggregation. completeFrames() adds display-only zero placeholders to keep all 12 identities in every frame and prevent exit animations below the plot. Missing labels have an asterisk and the table explicitly says Not reported. Reported zeros remain zero. Comparability can be affected by historical operational and classification changes.

The application starts paused. Start/end filters are inclusive; invalid ranges preserve the last valid chart. Filters apply via Apply filters; playback speed applies immediately. A one-month selection is a still frame. The timeline and data table support inspecting values without animation.

## Checks and dependencies

Run `npm test` with Node 20+. RacingBars was downloaded from https://registry.npmjs.org/racing-bars/-/racing-bars-0.5.0.tgz. Its license is in `docs/vendor/LICENSE-racing-bars`. API references: https://racing-bars.hatemhosny.dev/documentation/api/ and https://racing-bars.hatemhosny.dev/documentation/options/ .

## Chapter 2: Pandemic & recovery

Fixed January 2019–October 2023 window (58 months), with total airport traffic, domestic vs international, and arrivals vs departures. No date-range controls. Comparison and speed controls appear above the chart. The page opens with the complete overview; Replay draws the story from January 2019. Play/pause, reset, show full story, pointer inspection and keyboard arrows are supported. The x and y axes remain fixed across comparison modes. All terminal categories are summed; the original CSV is unchanged.

Recovery percentages compare each month with the same calendar month in 2019. Annual drop compares complete 2020 against complete 2019. October 2023 is compared only with October 2019, not with a full year. Between-month line interpolation is animation only. The four bilingual illustrated lessons read their code directly from recovery.js and recovery-model.js.

WHO event-month sources: https://www.who.int/europe/emergencies/situations/covid-19 . March 2020 marks pandemic characterization; May 2023 marks the end of the public health emergency of international concern, not disappearance of the disease. This descriptive dataset does not isolate causal policy effects.

Validation: monthly reconciliation of all four component series to original CSV rows, both split sums against airport totals, fixed coverage, same-month baselines, and narrative summaries. Browser checks include comparison switching, replay completion, reset/full story, keyboard inspection, navigation, and first-chapter rendering.

## New educational pages and handoff

The landing page is Introduction (#intro), followed by Terminal comparison, the empty Task page, Pandemic & recovery, and Extensions. How to create appears before the terminal code walkthrough and contains a tweening demo, a verified official RacingBars transition excerpt, short real-code excerpts, and one highlighted fill-in Copilot prompt. Extensions links to Apache ECharts and Flourish.

The three new HTML sections are authored in content/*.html and assembled with `python assemble-content.py`; docs/index.html is already assembled and runs as-is. education.js adds the slider, copy buttons and actual-source excerpt. See START-HERE.md for VS Code instructions and HANDOFF.md (in the continuation archive) for collaborator context. `python package-deliverables.py` builds the two distributable archives when that packaging script is included.

## November 2 editorial update

The intro emphasizes meaningful motion and story setup. The dataset preview shows original CSV rows with pagination, not field explanations. Task precedes Pandemic & recovery. Full ready-made LAX prompt removed; reusable template highlighted. Lesson snippets are limited to 2–4 source lines with actual file/line references; code-copy buttons removed. Official RacingBars transition provenance is in docs/excerpts/. The complete editable implementation remains in both downloads.
